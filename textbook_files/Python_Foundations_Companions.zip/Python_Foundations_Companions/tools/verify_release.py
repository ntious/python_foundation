"""Reproducible checks for the delivered Draft 7 companion package (standard library only)."""
from pathlib import Path
import ast,builtins,contextlib,hashlib,io,json,os,runpy,subprocess,sys,tempfile

BASE=Path(__file__).resolve().parents[1]
config=json.loads((BASE/'verification/expected_examples.json').read_text())
results=[]
def add(label,passed,**evidence):results.append({'check':label,'passed':bool(passed),**evidence})
def run(script,values,extra=None,echo=False):
 with tempfile.TemporaryDirectory(prefix='python_foundations_check_') as td:
  folder=Path(td)
  for file in (BASE/'data').iterdir():
   if file.is_file():(folder/file.name).write_bytes(file.read_bytes())
  for name,content in (extra or {}).items():(folder/name).write_bytes(content if isinstance(content,bytes) else content.encode())
  program=BASE/config['manifest'][script]
  if echo:
   bootstrap='import builtins,runpy,sys\nold=builtins.input\ndef inp(prompt=""):\n text=old()\n print(prompt+text)\n return text\nbuiltins.input=inp\nrunpy.run_path(sys.argv[1],run_name="__main__")\n'
   cmd=[sys.executable,'-c',bootstrap,str(program)]
  else:cmd=[sys.executable,str(program)]
  cp=subprocess.run(cmd,cwd=folder,input='\n'.join(values)+'\n',text=True,capture_output=True,timeout=10)
  created={p.name:p.read_bytes().hex() for p in folder.iterdir() if p.is_file() and p.name not in {q.name for q in (BASE/'data').iterdir()} and p.name not in (extra or {})}
  return cp,created

for name,path in config['manifest'].items():
 source=(BASE/path).read_bytes();add('source fingerprint '+name,hashlib.sha256(source).hexdigest()==config['source_sha256'][name])
 try:ast.parse(source,filename=name);add('compile '+name,True)
 except SyntaxError as error:add('compile '+name,False,error=str(error));continue
 cp,created=run(name,config['inputs'].get(name,[]))
 add('fresh process '+name,cp.returncode==0,exit_code=cp.returncode,stdout=cp.stdout,stderr=cp.stderr)
 if name in config['outputs'] and 'input(' not in source.decode() and name!='b_working_folder.py':add('printed output '+name,cp.stdout==config['outputs'][name],expected=config['outputs'][name],observed=cp.stdout)
 if name in config['samples']:
  cp,_=run(name,config['inputs'].get(name,[]),echo=True)
  add('printed sample '+name,cp.returncode==0 and cp.stdout==config['samples'][name],expected=config['samples'][name],observed=cp.stdout)

cases={
 'c04_label.py':[('empty label',[''],0,'Selected route:'),('other label',['Hill walk'],0,'Hill walk')],
 'c04_maps.py':[('zero',['0'],0,'Maps requested: 0'),('negative converts',['-2'],0,'Maps requested: -2'),('word fails',['six'],1,'ValueError')],
 'c04_distance.py':[('decimal',['Hill','0.5'],0,'0.5'),('word fails',['Hill','far'],1,'ValueError')],
 'c08_input.py':[('all zero',['0','0','0'],0,'Total refill actions: 0'),('word fails',['2','five'],1,'ValueError')],
 'c08_while.py':[('immediate done',['done'],0,'Topic list finished.'),('cleaned sentinel',[' DONE '],0,'Topic list finished.'),('blank retained',['','done'],0,'Queued:')],
 'c08_break.py':[('immediate done',['done'],0,'Session ended.'),('unrecognized',['other','done'],0,'Choose help or done.')],
 'c09_append.py':[('zero',['0','0'],0,'[0, 0]'),('negative retained',['-5','0'],0,'[-5, 0]'),('word fails',['14','fourteen'],1,'ValueError')],
 'c11_try.py':[('valid',['4'],0,'Recorded volunteers: 4'),('negative',['-1'],0,'cannot be negative'),('word',['four'],0,'Enter a whole number.')],
 'c11_retry.py':[('zero',['0'],0,'Accepted minutes: 0'),('upper',['1440'],0,'Accepted minutes: 1440'),('retry',['many','-1','1441','25'],0,'Accepted minutes: 25'),('cancel',['cancel'],0,'Entry cancelled.'),('retry cancel',['many','cancel'],0,'Entry cancelled.')],
 'c13_collect.py':[('empty',['done'],0,'No sessions to summarize.'),('blank then done',['','done'],0,'Enter a topic.'),('cancel retains earlier',['A','20','','B','many','cancel','done'],0,'Total minutes: 20')],
 'c13_join.py':[('new cancel',['','done','cancel'],0,'Starting a new collection.'),('missing',['missing.csv'],0,'file not found')],
 'study_tracker.py':[('new empty',['','done','cancel'],0,'No new file saved.'),('missing',['missing.csv'],0,'file not found'),('invalid later',['study_bad_minutes.csv'],0,'Record 3: use whole minutes.'),('short',['study_short_row.csv'],0,'expected three fields'),('surplus',['study_extra_row.csv'],0,'expected three fields'),('header only',['study_header_only.csv','done','cancel'],0,'No sessions to summarize.'),('BOM',['study_utf8_bom.csv','done','cancel'],0,'Total minutes: 25'),('cancel entry',['','A','cancel','done','cancel'],0,'Sessions: 0')],
 'ans04.py':[('valid',['Other','0','0.5'],0,'Fasteners: 0'),('word fails',['Other','eight'],1,'ValueError')],
 'ans08.py':[('zeros',['0','0','0','0'],0,'Total donated blankets: 0'),('word fails',['3','many'],1,'ValueError')],
 'ans11.py':[('within',['12'],0,'Within the allowance.'),('above',['13'],0,'Above the allowance.'),('zero',['0'],0,'Within the allowance.'),('retry cancel',['many','-1','cancel'],0,'No count recorded.')],
 'refill_complete.py':[('equal',['Test','300','400','500'],0,'Within the planning threshold.'),('above',['Test','5','224','972'],0,'Review the next supply plan.'),('zero',['Test','0','0','0'],0,'0.00 L'),('bad middle',['Test','300','many','500'],0,'Summary withheld'),('negative',['Test','300','-1','500'],0,'Summary withheld'),('fraction',['Test','300','224.5','500'],0,'Summary withheld'),('upper accepted',['Test','10000','0','0'],0,'100.00 L'),('above range',['Test','10001','0','0'],0,'Summary withheld'),('accepted conversion forms',['Test','+300','0400','5_00'],0,'12.00 L')]
}
for script,tests in cases.items():
 for label,values,status,expected in tests:
  cp,created=run(script,values)
  add(script+' '+label,(cp.returncode==0 if status==0 else cp.returncode!=0) and expected in cp.stdout+cp.stderr,exit_code=cp.returncode,stdout=cp.stdout,stderr=cp.stderr)
  if script=='study_tracker.py' and label in ['missing','invalid later','short','surplus','cancel entry']:add('rejected/cancelled run creates no export '+label,not created)

extra_cases=[('wrong header','topic,Minutes,note\nA,5,\n','Expected topic,minutes,note.'),('empty topic','topic,minutes,note\n ,5,\n','enter a topic.'),('negative duration','topic,minutes,note\nA,-1,\n','minutes need 0-1440'),('encoding',b'\xff\xfe\x00\x00','text is not UTF-8'),('CSV quoting','topic,minutes,note\n"unfinished,5,note\n','malformed CSV')]
for label,content,message in extra_cases:
 cp,created=run('study_tracker.py',['invalid.csv'],{'invalid.csv':content})
 add('specific load recovery '+label,cp.returncode==0 and message in cp.stdout and not created,stdout=cp.stdout,stderr=cp.stderr)

# Imports must be silent and cannot start input prompts.
for script in ['study_tracker.py','c13_join.py']:
 path=BASE/config['manifest'][script]
 cp=subprocess.run([sys.executable,'-c','import runpy,sys; runpy.run_path(sys.argv[1],run_name="review_import")',str(path)],capture_output=True,text=True,timeout=10)
 add('silent import '+script,cp.returncode==0 and cp.stdout=='' and cp.stderr=='',stdout=cp.stdout,stderr=cp.stderr)

# Controlled exception injection checks handlers that depend on device permissions.
# These are boundary simulations, not operating-system permission trials.
module=runpy.run_path(str(BASE/config['manifest']['study_tracker.py']),run_name='review_import')
run_tracker=module['run_tracker'];globals_=run_tracker.__globals__;original_loader=globals_['load_sessions']
for cls,message in [(PermissionError,'permission denied'),(OSError,'file access failed')]:
 def fail_load(filename,cls=cls):raise cls('controlled test')
 globals_['load_sessions']=fail_load;oldinput=builtins.input;builtins.input=lambda prompt='':'test.csv';buf=io.StringIO()
 try:
  with contextlib.redirect_stdout(buf):run_tracker()
  add('simulated handler '+cls.__name__,message in buf.getvalue(),stdout=buf.getvalue())
 finally:builtins.input=oldinput;globals_['load_sessions']=original_loader
def programming_error(filename):raise NameError('controlled programming error')
globals_['load_sessions']=programming_error;oldinput=builtins.input;builtins.input=lambda prompt='':'test.csv'
try:
 try:run_tracker()
 except NameError:add('programming errors remain visible',True)
 else:add('programming errors remain visible',False)
finally:builtins.input=oldinput;globals_['load_sessions']=original_loader

# Actual lifecycle in one directory proves persistence, retry, and preservation.
with tempfile.TemporaryDirectory(prefix='tracker_lifecycle_') as td:
 folder=Path(td)
 for file in (BASE/'data').iterdir():(folder/file.name).write_bytes(file.read_bytes())
 tracker=BASE/config['manifest']['study_tracker.py']
 def interaction(values):return subprocess.run([sys.executable,str(tracker)],cwd=folder,input='\n'.join(values)+'\n',capture_output=True,text=True,timeout=10)
 first=interaction(['study_seed.csv','done','first.csv']);saved=(folder/'first.csv').read_bytes()
 second=interaction(['first.csv','Extra','10','Keep, comma','done','first.csv','second.csv'])
 add('save and append lifecycle',first.returncode==second.returncode==0 and 'Total minutes: 70' in second.stdout and '23.3' in second.stdout and 'File exists. Use a new name.' in second.stdout)
 add('original export byte-preserved',(folder/'first.csv').read_bytes()==saved)
 import csv
 with (folder/'second.csv').open(newline='') as f:records=list(csv.DictReader(f))
 add('all fields and order preserved',records==[{'topic':'Essay plan','minutes':'25','note':'Outline, then sources'},{'topic':'Python practice','minutes':'35','note':'Trace a loop'},{'topic':'Extra','minutes':'10','note':'Keep, comma'}])

# Decode notebook JSON and execute code cells in order in a fresh namespace per notebook.
notebook_cells=0
for file in sorted((BASE/'notebooks').glob('*.ipynb')):
 data=json.loads(file.read_text());ns={'__name__':'__main__'};oldcwd=os.getcwd();ok=True
 try:
  for cell in data['cells']:
   if cell['cell_type']!='code':continue
   notebook_cells+=1;source=''.join(cell['source'])
   name=next((n for n,path in config['manifest'].items() if (BASE/path).read_text()==source),None)
   values=list(config['inputs'].get(name,[]))
   if name=='c13_join.py':values=['study_seed.csv','done','joined.csv']
   if name=='study_tracker.py':values=['study_seed.csv','done','tracker.csv']
   iterator=iter(values);oldinput=builtins.input;builtins.input=lambda prompt='':next(iterator)
   try:
    with contextlib.redirect_stdout(io.StringIO()):exec(compile(source,file.name,'exec'),ns)
   finally:builtins.input=oldinput
  add('notebook execution '+file.name,True)
 except Exception as error:ok=False;add('notebook execution '+file.name,False,error=repr(error))
 finally:os.chdir(oldcwd)
 add('notebook outputs cleared '+file.name,all(c.get('execution_count') is None and not c.get('outputs') for c in data['cells'] if c['cell_type']=='code'))

for path,exception in config['deliberate_errors'].items():
 cp=subprocess.run([sys.executable,str(BASE/path)],capture_output=True,text=True,timeout=10)
 add('expected deliberate failure '+path,cp.returncode!=0 and exception+':' in cp.stderr,stderr=cp.stderr)

report={'python':sys.version,'platform':sys.platform,'checks':results,'check_count':len(results),'failed':[x for x in results if not x['passed']],'notebook_code_cells':notebook_cells}
output=Path(sys.argv[1]) if len(sys.argv)>1 else BASE/'verification/execution_results.json'
output.write_text(json.dumps(report,indent=2))
print(json.dumps({'checks':len(results),'failures':len(report['failed']),'notebook_code_cells':notebook_cells,'failed':report['failed']},indent=2))
raise SystemExit(bool(report['failed']))
