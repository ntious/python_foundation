journey_minutes = [12, 18, 15, 21]
print(journey_minutes[4])
