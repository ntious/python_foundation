maps_text = "12"
print(maps_text + 7)
