items = 12
volunteers = 0
items_per_volunteer = items / volunteers
