print("Collection desk opens soon."
