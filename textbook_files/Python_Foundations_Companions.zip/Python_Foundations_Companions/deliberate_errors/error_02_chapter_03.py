seedlings = 18
print(seedling)
