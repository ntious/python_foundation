# Python Foundations Draft 8 revision notes

Prepared for Isaac K. Nti · 7 November 2026.

Draft 8 adds the author-approved Acknowledgments after the Preface and About the Author before the Index. The acknowledgments thank the author’s wife and children for their support and Joshua Berko for reviewing the initial draft. The biography includes a working link to https://github.com/ntious.

The contents includes both sections and was checked against all 25 destinations in the 191-page PDF. All 15 instructional illustrations remain. The clean Word file has no reviewer comments or tracked changes. Chapter content, code, exercises, solutions, and the technical revisions from Draft 7 are retained.

The matching Draft 8 companions carry the existing Draft 7 technical response and records as historical documents. The release checker was rerun for Draft 8: 463 checks passed with zero failures, including the 13 notebooks and their 86 code cells. Code was not changed in this edition update. The provenance inventory adds the two author-approved sections; unresolved provenance and permission confirmations for other material remain open.

Independent beginner trials, platform-specific interface checks, specialist accessibility review, and a physical print proof remain prepublication checks. Word may repaginate on another computer; use the matching PDF for this edition’s page references.
