# Draft 7 execution record

Prepared 7 November 2026 for Isaac K. Nti.

## Environment and scope

- Interpreter: 3.12.14 (main, Aug 25 2026, 14:00:49) [Clang 22.1.3 ].
- Platform: linux.
- Source: clean Draft 7 Word manuscript and the exact companion files delivered with it.
- This is implementation verification performed during revision, not an independent human editorial or learner trial.

## Results

- 90 named programs compiled and ran in separate fresh working folders.
- 90 distributed sources matched their printed manuscript programs; c13_join.py includes the preceding function definitions exactly as its assembly instruction specifies.
- 73 comparable noninteractive output blocks matched exactly.
- All 15 printed sample runs matched with the stated user responses echoed.
- All 16 input-driven programs received case-specific additional tests. Deliberately unvalidated early examples were tested for the limitations the book describes, rather than incorrectly treated as fully validated applications.
- Six deliberate-error programs produced their expected exception classes.
- All 13 notebooks executed their 86 code cells in chapter order, with a fresh namespace per notebook. Outputs and execution counts are cleared for delivery.
- The release checker passed 463 checks, with 0 failures. A check count includes source fingerprints, compilation, execution, expected outputs, selected interactions, and notebook checks; it is not a count of distinct learner scenarios.
- An additional 43 focused checks and 125 supplementary checks passed during package generation. These overlap the release checker and are not claimed as additional unique scenarios.
- The tracker passed valid load, invalid later record rejection, empty data, duration bounds, retry and cancellation, BOM input, encoding and malformed CSV rejection, silent import, exclusive-save retry, unchanged original export, reopening, appended record order, and comma-containing note preservation.
- PermissionError and generic OSError handlers were exercised through explicitly labelled controlled exception injection. They are not claims of real operating-system permission trials. Programming NameError was confirmed to remain visible.

## Reproduce the checks

Extract Python_Foundations_Draft_7_Companions.zip. In its top-level folder, run the checker with your Python 3.12-or-later interpreter:

```bash
python3 tools/verify_release.py
```

On Windows with the Python launcher and Python 3.12 installed, use:

```text
py -3.12 tools/verify_release.py
```

The checker uses only the standard library. It runs examples in temporary folders and writes verification/execution_results.json. A final nonzero exit code means at least one check failed. Review the failed entries before accepting the result.

verification/expected_examples.json contains source fingerprints, paths, sample inputs, expected outputs, and expected deliberate errors. verification/base_checks.json retains the earlier focused checks. verification/contents_check.json and verification/index_audit.json record navigation checks.

## Limits

No independent learner study, live IDLE interface test, live Colab test, other operating-system test, other Python-version execution, physical print proof, or accessibility-conformance audit is claimed. Error wording may vary on other supported Python versions. Provenance confirmation remains an author responsibility.
