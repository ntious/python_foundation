import math
 
cards = 19
cards_per_box = 6
boxes_needed = math.ceil(cards / cards_per_box)
print("Boxes needed:", boxes_needed)
