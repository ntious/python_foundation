# Author confirmation before publication

This is an open confirmation list, not a record of completed permissions checks.

1. Review PROVENANCE_INVENTORY.csv. For each chapter or asset, identify whether it was newly developed for the book, retained from the earlier course, or obtained from another source. Add source URLs/files and exact retained passages where applicable.
2. Confirm the rights policy you intend for new book prose and illustrations. The revision preserves the existing policy; it does not apply a new blanket license.
3. Confirm that code offered under MIT is owned by you or available on compatible terms, and that any required third-party notices are retained.
4. Confirm illustration creators and sources, and check any upstream or institutional exclusions. Draft history alone does not prove authorship or permission.
5. Verify the DejaVu font distribution/embedding terms for the final publishing workflow and retain any required notices.
6. Arrange the actual companion download method and insert only a real, tested distribution link. The package filename in this review edition is not a live hosting promise.
7. Arrange independent beginner trials, relevant IDLE/Colab interface trials, a specialist accessibility audit, and a physical print proof before publication.

Fill in the inventory’s author_confirmation column and resolve uncertain material with the appropriate rights holder or publishing adviser. Do not infer legal approval from the code checks.
