# Beginner reader trial

This is a proposed trial protocol. No participant observations are claimed.

Ask a willing beginner to work from the revised book and matching companions. Record where they need help before explaining the answer. Use invented data and record no unnecessary personal information.

| Task | Evidence to observe | Observation | Help needed | Revision to consider |
| --- | --- | --- | --- | --- |
| Locate the editor and Shell, change a notice, save and reopen it | Learner distinguishes source, filename, latest run, and output | | | |
| Predict integer reassignment, then shared-list mutation | Learner can explain why the two examples differ | | | |
| Trace overlapping booking conditions at 15, 16, 19, and 20 | Branch selection agrees with the stated boundaries | | | |
| Compare the faulty and corrected text-alternative conditions | Learner recognizes the string result and repeated comparisons | | | |
| Run an exclusive-file example twice | Learner anticipates FileExistsError and can recover | | | |
| Read a CSV placed in a wrong folder, then correct its location | Learner can find the working folder and interpret the missing filename | | | |
| Work through collection, loading, saving, and integration checkpoints | Learner can explain the responsibility and test of each stage | | | |
| Save and reopen a tracker export containing a comma in a note | All fields and record order survive, with documented normalization | | | |

After the trial, ask which instruction was least clear and which example helped most. Keep observations separate from interpretation. Record the book section, task, expected result, observed action, help given, and proposed change. Follow an unsuccessful task with another independent reader after revision if possible.
