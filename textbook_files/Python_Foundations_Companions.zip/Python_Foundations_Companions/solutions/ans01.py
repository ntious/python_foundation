# The display tables are reserved for catalogued books.
print("Riverside Reading Hall")
print("Arrange catalogued books on the tables.")
print("Return empty boxes to the entrance desk.")
