def model_length_cm(real_length_m):
    return real_length_m * 2
 
for real_m in [0, 3.5, 12]:
    model_cm = model_length_cm(real_m)
    print("Model centimeters:", model_cm)
