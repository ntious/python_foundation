print("Bicycle marking at the north gate.")
print("Bring your registration card.")
