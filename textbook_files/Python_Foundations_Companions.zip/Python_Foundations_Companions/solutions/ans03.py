display_title = "Tools of the riverside workshop"
object_count = 14
case_width_cm = 92.5
label_ready = True
 
print("Display:", display_title)
print("Objects:", object_count)
print("Case width in cm:", case_width_cm)
print("Label ready:", label_ready)
