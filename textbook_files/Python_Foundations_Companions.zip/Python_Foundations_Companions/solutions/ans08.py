total_blankets = 0
 
for point_index in range(4):
    count = int(input("Blankets at this point: "))
    total_blankets = total_blankets + count
 
print("Total donated blankets:", total_blankets)
