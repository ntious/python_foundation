def read_count():
    while True:
        text = input("Item count (or cancel): ").strip()
        if text.lower() == "cancel":
            return None
        try:
            count = int(text)
        except ValueError:
            print("Use a whole number.")
        else:
            if count >= 0:
                return count
            print("Use a nonnegative count.")
 
items = read_count()
if items is None:
    print("No count recorded.")
elif items <= 12:
    print("Within the allowance.")
else:
    print("Above the allowance.")
