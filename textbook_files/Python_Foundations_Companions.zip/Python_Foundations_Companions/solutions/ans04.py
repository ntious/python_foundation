item_label = input("Item label: ")
fasteners = int(input("Whole fastener count: "))
cord_m = float(input("Cord length in meters: "))
 
print("Item:", item_label)
print("Fasteners:", fasteners)
print("Cord meters:", cord_m)
