import csv
 
def load_sessions(filename):
    sessions = []
    fields = ["topic", "minutes", "note"]
    with open(filename, "r", encoding="utf-8-sig",
              newline="") as data:
        reader = csv.DictReader(data, strict=True)
        if reader.fieldnames != fields:
            raise ValueError(
                "Expected topic,minutes,note.")
        row_number = 1
        for row in reader:
            row_number += 1
            if None in row or None in row.values():
                raise ValueError(
                    f"Record {row_number}: expected three fields.")
            topic = row["topic"].strip()
            try:
                minutes = int(row["minutes"])
            except ValueError:
                raise ValueError(
                    f"Record {row_number}: use whole minutes.")
            if topic == "":
                raise ValueError(
                    f"Record {row_number}: enter a topic.")
            if minutes < 0 or minutes > 1440:
                raise ValueError(
                    f"Record {row_number}: minutes need 0-1440.")
            sessions.append({
                "topic": topic,
                "minutes": minutes,
                "note": row["note"],
            })
    return sessions
 
sessions = load_sessions("study_seed.csv")
total_minutes = 0
for session in sessions:
    print("Topic:", session["topic"])
    total_minutes += session["minutes"]
print("Sessions:", len(sessions))
print("Total minutes:", total_minutes)
