category_text = "  PHOTOGRAPHS  "
category = category_text.strip()
category = category.lower()
 
if category == "oral history":
    print("Visit the listening desk.")
elif category == "photographs":
    print("Visit the image desk.")
else:
    print("Ask the archive team.")
