room_booked = True
boards_available = False
rails_available = True
 
ready = room_booked and (
    boards_available or rails_available
)
print("Exhibition ready:", ready)
