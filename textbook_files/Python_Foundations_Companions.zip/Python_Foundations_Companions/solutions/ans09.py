wait_minutes = [6, 11, 8, 15, 10]
 
if len(wait_minutes) > 0:
    total_minutes = sum(wait_minutes)
    mean_minutes = total_minutes / len(wait_minutes)
    print("Observations:", len(wait_minutes))
    print("Total minutes:", total_minutes)
    print(f"Mean wait: {mean_minutes:.1f} min")
    for minutes in wait_minutes:
        if minutes > 10:
            print("Above target:", minutes, "min")
else:
    print("No waits have been recorded.")
