strips = 7
strip_length_m = 1.25
repair_reserve_m = 0.75
available_m = 9.50
required_m = strips * strip_length_m + repair_reserve_m
 
print(f"Required fabric: {required_m:.2f} m")
print(f"Available fabric: {available_m:.2f} m")
print("Sufficient:", available_m >= required_m)
