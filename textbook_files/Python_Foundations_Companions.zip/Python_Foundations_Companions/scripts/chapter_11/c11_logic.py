weight_kg = 5.0
 
if weight_kg < 5:
    print("Use the small-item table.")
else:
    print("Ask for a larger-item location.")
