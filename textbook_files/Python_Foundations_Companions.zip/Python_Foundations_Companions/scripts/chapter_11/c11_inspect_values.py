items = 12
volunteers = 0
print("volunteers:", volunteers)
print("type:", type(volunteers))
