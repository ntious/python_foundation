count_text = input("Whole number of volunteers: ")
 
try:
    volunteers = int(count_text)
except ValueError:
    print("Enter a whole number.")
else:
    if volunteers >= 0:
        print("Recorded volunteers:", volunteers)
    else:
        print("The count cannot be negative.")
