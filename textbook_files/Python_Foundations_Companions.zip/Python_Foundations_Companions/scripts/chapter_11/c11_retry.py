def read_minutes():
    while True:
        text = input(
            "Minutes (0-1440, or cancel): ").strip()
        if text.lower() == "cancel":
            return None
        try:
            minutes = int(text)
        except ValueError:
            print("Use whole minutes.")
        else:
            if 0 <= minutes <= 1440:
                return minutes
            print("Choose a value from 0 to 1440.")
 
result = read_minutes()
if result is None:
    print("Entry cancelled.")
else:
    print("Accepted minutes:", result)
