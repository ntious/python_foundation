import csv
 
filenames = [
    "study_short_row.csv", "study_extra_row.csv"
]
for filename in filenames:
    print(filename)
    with open(filename, "r", encoding="utf-8-sig",
              newline="") as data:
        reader = csv.DictReader(data)
        for row in reader:
            print(row)
