with open("reading_note.txt", "r",
          encoding="utf-8-sig") as note:
    contents = note.read()
print(contents, end="")
