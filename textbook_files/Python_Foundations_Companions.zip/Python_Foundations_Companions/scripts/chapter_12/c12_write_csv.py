import csv
 
sessions = [
    {"topic": "Essay plan", "minutes": 25,
     "note": "Outline, then sources"},
    {"topic": "Python practice", "minutes": 35,
     "note": "Trace a loop"},
]
fields = ["topic", "minutes", "note"]
with open("study_export_01.csv", "x",
          encoding="utf-8", newline="") as data:
    writer = csv.DictWriter(data, fieldnames=fields)
    writer.writeheader()
    writer.writerows(sessions)
print("Saved study_export_01.csv")
