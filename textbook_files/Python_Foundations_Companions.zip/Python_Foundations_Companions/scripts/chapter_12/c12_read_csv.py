import csv
 
total_minutes = 0
with open("study_seed.csv", "r",
          encoding="utf-8-sig", newline="") as data:
    reader = csv.DictReader(data, strict=True)
    fields = ["topic", "minutes", "note"]
    if reader.fieldnames != fields:
        raise ValueError("Expected topic,minutes,note.")
    for row in reader:
        if None in row or None in row.values():
            raise ValueError("Check the row fields.")
        topic = row["topic"].strip()
        minutes = int(row["minutes"])
        if topic == "" or minutes < 0 or minutes > 1440:
            raise ValueError("Check topic and minutes.")
        print(topic, "-", minutes, "min")
        total_minutes += minutes
print("Total minutes:", total_minutes)
