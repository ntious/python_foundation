import csv
 
fields = ["topic", "minutes", "note"]
with open("study_seed.csv", "r",
          encoding="utf-8-sig", newline="") as data:
    reader = csv.DictReader(data)
    if reader.fieldnames != fields:
        raise ValueError("Check the CSV header.")
    print("Header accepted.")
