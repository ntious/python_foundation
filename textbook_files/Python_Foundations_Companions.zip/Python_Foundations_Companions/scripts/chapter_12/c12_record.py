photograph = {
    "title": "Bridge opening",
    "year": 1964,
    "location": "Harbor quay",
}
print("Title:", photograph["title"])
print("Recorded year:", photograph["year"])
