import csv
 
total_minutes = 0
with open("study_seed.csv", "r",
          encoding="utf-8-sig", newline="") as data:
    reader = csv.DictReader(data)
    for row in reader:
        minutes = int(row["minutes"])
        total_minutes = total_minutes + minutes
print("Total minutes:", total_minutes)
