import csv
 
with open("study_seed.csv", "r",
          encoding="utf-8-sig", newline="") as data:
    reader = csv.DictReader(data)
    for row in reader:
        print("Topic:", row["topic"])
        print("Minutes text:", row["minutes"])
        print("Note:", row["note"])
        print("Minutes type:", type(row["minutes"]))
