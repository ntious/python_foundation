photograph = {"title": "Bridge opening", "year": 1964}
photograph["year"] = 1965
print("Title:", photograph["title"])
print("Revised year:", photograph["year"])
