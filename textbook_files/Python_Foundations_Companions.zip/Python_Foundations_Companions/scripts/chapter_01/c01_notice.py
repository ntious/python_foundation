print("Seed exchange preparation")
print("Count sealed packets first.")
print("Record damaged packets separately.")
