# Only sealed packets belong in visitor bundles.
print("Use sealed packets for the exchange.")
