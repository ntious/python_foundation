print("Record damaged packets separately.")
print("Count sealed packets first.")
print("Seed exchange preparation")
