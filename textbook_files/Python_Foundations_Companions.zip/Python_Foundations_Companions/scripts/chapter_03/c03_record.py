bed_label = "West bed"
seedlings = 18
bed_length_m = 4.5
planting_complete = False
 
print("Bed:", bed_label)
print("Seedlings:", seedlings)
print("Length in meters:", bed_length_m)
print("Planting complete:", planting_complete)
