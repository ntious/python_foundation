title = "Harbor voices"
shelf = "Local writing"
print("Title:", title)
print("Shelf:", shelf)
title = "Evening letters"
print("Revised title:", title)
