bed_label = "West bed"
print("bed_label")
print(bed_label)
