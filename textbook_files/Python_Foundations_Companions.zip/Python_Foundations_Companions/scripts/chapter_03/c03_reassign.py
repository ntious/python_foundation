seedlings = 18
recorded_seedlings = seedlings
seedlings = 24
 
print("Recorded count:", recorded_seedlings)
print("Current count:", seedlings)
