seedlings = 18
bed_label = "West bed"
 
print(type(seedlings))
print(type(bed_label))
