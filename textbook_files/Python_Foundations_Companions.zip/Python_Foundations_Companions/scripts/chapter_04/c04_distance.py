route_label = input("Route label: ")
distance_text = input("Distance in kilometers: ")
distance_km = float(distance_text)
 
print("Route:", route_label)
print("Planned kilometers:", distance_km)
