route_code = "007"
print("Route code:", route_code)
print("Converted number:", int(route_code))
