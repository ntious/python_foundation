first_text = "12"
second_text = "7"
print("Joined text:", first_text + second_text)
print("Total items:", int(first_text) + int(second_text))
