category_text = "  Oral History  "
category = category_text.strip()
search_category = category.lower()
print("Original:", "[" + category_text + "]")
print("Clean label:", "[" + category + "]")
print("Search form:", search_category)
