maps_text = input("Whole number of maps: ")
maps_needed = int(maps_text)
 
print("Before conversion:", type(maps_text))
print("After conversion:", type(maps_needed))
print("Maps requested:", maps_needed)
