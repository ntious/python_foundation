route_label = input("Route label: ")
print("Selected route:", route_label)
