chairs_arranged = False
 
if not chairs_arranged:
    print("Arrange the chairs before opening.")
