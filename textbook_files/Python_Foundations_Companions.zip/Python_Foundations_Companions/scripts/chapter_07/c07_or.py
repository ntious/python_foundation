rain_forecast = False
strong_wind_forecast = True
 
if rain_forecast or strong_wind_forecast:
    print("Confirm the indoor arrangement.")
else:
    print("No weather-related planning notice.")
