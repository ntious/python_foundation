venue_permission = True
dry_forecast = False
 
if venue_permission and dry_forecast:
    print("Use the garden venue.")
else:
    print("Use the indoor plan.")
