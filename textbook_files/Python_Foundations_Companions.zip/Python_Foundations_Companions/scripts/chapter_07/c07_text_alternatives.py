choice = "roof"
print(choice == "garden" or "hall")
print(choice == "garden" or choice == "hall")
