venue_permission = True
own_projector_ready = False
borrowed_projector_ready = True
 
equipment_ready = (
    own_projector_ready or borrowed_projector_ready
)
event_ready = venue_permission and equipment_ready
 
print("Equipment ready:", equipment_ready)
print("Event ready:", event_ready)
