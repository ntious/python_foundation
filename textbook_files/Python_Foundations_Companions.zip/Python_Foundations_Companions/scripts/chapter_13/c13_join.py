import csv
 
 
def load_sessions(filename):
    sessions = []
    fields = ["topic", "minutes", "note"]
    with open(filename, "r", encoding="utf-8-sig",
              newline="") as data:
        reader = csv.DictReader(data, strict=True)
        if reader.fieldnames != fields:
            raise ValueError(
                "Expected topic,minutes,note.")
        row_number = 1
        for row in reader:
            row_number += 1
            if None in row or None in row.values():
                raise ValueError(
                    f"Record {row_number}: expected three fields.")
            topic = row["topic"].strip()
            try:
                minutes = int(row["minutes"])
            except ValueError:
                raise ValueError(
                    f"Record {row_number}: use whole minutes.")
            if topic == "":
                raise ValueError(
                    f"Record {row_number}: enter a topic.")
            if minutes < 0 or minutes > 1440:
                raise ValueError(
                    f"Record {row_number}: minutes need 0-1440.")
            sessions.append({
                "topic": topic,
                "minutes": minutes,
                "note": row["note"],
            })
    return sessions
 
 
def save_sessions(filename, sessions):
    fields = ["topic", "minutes", "note"]
    with open(filename, "x", encoding="utf-8",
              newline="") as data:
        writer = csv.DictWriter(data, fieldnames=fields)
        writer.writeheader()
        writer.writerows(sessions)
 
 
def report_sessions(sessions):
    print("Sessions:", len(sessions))
    if len(sessions) == 0:
        print("No sessions to summarize.")
        return
    total_minutes = 0
    for session in sessions:
        total_minutes += session["minutes"]
    mean_minutes = total_minutes / len(sessions)
    print("Total minutes:", total_minutes)
    print(f"Mean minutes: {mean_minutes:.1f}")
    print("60-minute goal met:", total_minutes >= 60)
 
 
def read_minutes():
    while True:
        text = input(
            "Minutes (0-1440, or cancel): ").strip()
        if text.lower() == "cancel":
            return None
        try:
            minutes = int(text)
        except ValueError:
            print("Use whole minutes.")
        else:
            if 0 <= minutes <= 1440:
                return minutes
            print("Choose a value from 0 to 1440.")
 
 
def collect_sessions(sessions):
    while True:
        topic = input("Topic (or done): ").strip()
        if topic.lower() == "done":
            return
        if topic == "":
            print("Enter a topic.")
        else:
            minutes = read_minutes()
            if minutes is None:
                print("Entry cancelled.")
            else:
                note = input("Note (Enter for none): ")
                sessions.append({
                    "topic": topic,
                    "minutes": minutes,
                    "note": note,
                })
                print("Session added.")
 
 
def run_tracker():
    source = input("Open CSV (Enter for new): ").strip()
    if source == "":
        sessions = []
        print("Starting a new collection.")
    else:
        try:
            sessions = load_sessions(source)
        except FileNotFoundError:
            print("Could not load: file not found.")
            print("Check filename and working folder.")
            return
        except PermissionError:
            print("Could not load: permission denied.")
            print("Choose a file you can read.")
            return
        except UnicodeError:
            print("Could not load: text is not UTF-8.")
            print("Save a UTF-8 CSV copy and retry.")
            return
        except csv.Error:
            print("Could not load: malformed CSV.")
            print("Check quoting and field separators.")
            return
        except ValueError as error:
            print("Could not load:", error)
            return
        except OSError:
            print("Could not load: file access failed.")
            print("Check the location and permissions.")
            return
        print("Loaded sessions:", len(sessions))
    collect_sessions(sessions)
    report_sessions(sessions)
    while True:
        target = input(
            "Save as NEW CSV (or cancel): ").strip()
        if target.lower() == "cancel":
            print("No new file saved.")
            return
        if target == "":
            print("Enter a new filename.")
        else:
            try:
                save_sessions(target, sessions)
            except FileExistsError:
                print("File exists. Use a new name.")
            except OSError:
                print("Save failed. Check path.")
            else:
                print("Saved:", target)
                return

if __name__ == "__main__":
    run_tracker()
