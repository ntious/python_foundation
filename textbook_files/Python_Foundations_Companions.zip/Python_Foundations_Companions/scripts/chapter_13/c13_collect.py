def report_sessions(sessions):
    print("Sessions:", len(sessions))
    if len(sessions) == 0:
        print("No sessions to summarize.")
        return
    total_minutes = 0
    for session in sessions:
        total_minutes += session["minutes"]
    mean_minutes = total_minutes / len(sessions)
    print("Total minutes:", total_minutes)
    print(f"Mean minutes: {mean_minutes:.1f}")
    print("60-minute goal met:", total_minutes >= 60)
 
 
def read_minutes():
    while True:
        text = input(
            "Minutes (0-1440, or cancel): ").strip()
        if text.lower() == "cancel":
            return None
        try:
            minutes = int(text)
        except ValueError:
            print("Use whole minutes.")
        else:
            if 0 <= minutes <= 1440:
                return minutes
            print("Choose a value from 0 to 1440.")
 
 
def collect_sessions(sessions):
    while True:
        topic = input("Topic (or done): ").strip()
        if topic.lower() == "done":
            return
        if topic == "":
            print("Enter a topic.")
        else:
            minutes = read_minutes()
            if minutes is None:
                print("Entry cancelled.")
            else:
                note = input("Note (Enter for none): ")
                sessions.append({
                    "topic": topic,
                    "minutes": minutes,
                    "note": note,
                })
                print("Session added.")
 
sessions = []
collect_sessions(sessions)
report_sessions(sessions)
