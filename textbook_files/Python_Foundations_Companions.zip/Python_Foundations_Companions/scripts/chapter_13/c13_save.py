import csv

def save_sessions(filename, sessions):
    fields = ["topic", "minutes", "note"]
    with open(filename, "x", encoding="utf-8",
              newline="") as data:
        writer = csv.DictWriter(data, fieldnames=fields)
        writer.writeheader()
        writer.writerows(sessions)

sessions = [
    {"topic": "Essay plan", "minutes": 25,
     "note": "Outline, then sources"},
    {"topic": "Python practice", "minutes": 35,
     "note": "Trace a loop"},
]
try:
    save_sessions("checkpoint_export.csv", sessions)
except FileExistsError:
    print("File exists. Use a new name.")
except OSError:
    print("Save failed. Check the working folder.")
else:
    print("Saved checkpoint_export.csv")
