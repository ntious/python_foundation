sessions = [
    {"topic": "Essay plan", "minutes": 25,
     "note": "Outline, then sources"},
    {"topic": "Python practice", "minutes": 35,
     "note": "Trace a loop"},
]
total_minutes = 0
for session in sessions:
    total_minutes += session["minutes"]
print("Sessions:", len(sessions))
print("Total minutes:", total_minutes)
mean_minutes = total_minutes / len(sessions)
print(f"Mean minutes: {mean_minutes:.1f}")
print("60-minute goal met:", total_minutes >= 60)
