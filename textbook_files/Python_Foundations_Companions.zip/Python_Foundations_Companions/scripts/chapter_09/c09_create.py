journey_minutes = [12, 18, 15, 21]
 
print("Journey minutes:", journey_minutes)
print("Number of journeys:", len(journey_minutes))
print("First journey:", journey_minutes[0])
