journey_minutes = [12, 18, 15, 21]
journey_minutes[1] = 16
print("Corrected minutes:", journey_minutes)
print("Observation count:", len(journey_minutes))
