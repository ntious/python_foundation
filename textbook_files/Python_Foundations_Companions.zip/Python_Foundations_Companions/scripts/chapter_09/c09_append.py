journey_minutes = []
 
for journey_index in range(2):
    print("Journey", journey_index + 1)
    minutes = int(input("Whole minutes: "))
    journey_minutes.append(minutes)
 
print("Recorded minutes:", journey_minutes)
