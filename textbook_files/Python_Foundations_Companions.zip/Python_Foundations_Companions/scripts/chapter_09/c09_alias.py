journey_minutes = [12, 18]
review_minutes = journey_minutes
review_minutes.append(15)
 
print("Original name:", journey_minutes)
print("Review name:", review_minutes)
