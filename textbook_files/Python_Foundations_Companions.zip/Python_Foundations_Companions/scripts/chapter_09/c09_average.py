journey_minutes = [12, 16, 15, 21]
 
if len(journey_minutes) > 0:
    total_minutes = sum(journey_minutes)
    mean_minutes = total_minutes / len(journey_minutes)
    print("Total minutes:", total_minutes)
    print(f"Mean journey time: {mean_minutes:.1f} min")
else:
    print("No journeys have been recorded.")
