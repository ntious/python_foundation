journey_minutes = [12, 16, 15, 21]
target_minutes = 16
 
for minutes in journey_minutes:
    if minutes > target_minutes:
        print(minutes, "minutes: above planning target")
    else:
        print(minutes, "minutes: within planning target")
