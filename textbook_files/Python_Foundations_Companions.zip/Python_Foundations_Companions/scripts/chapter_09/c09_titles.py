titles = [
    "River market letters",
    "Hill school notes",
    "River ferry diary",
]
for title in titles:
    if "river" in title.lower():
        print(title)
