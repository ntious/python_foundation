first_cl = 5
second_cl = 224
third_cl = 971
total_cl = first_cl + second_cl + third_cl
 
print("Recorded centiliters:", total_cl)
print(f"Displayed liters: {total_cl / 100:.2f}")
print("Above 12 liters:", total_cl > 1200)
