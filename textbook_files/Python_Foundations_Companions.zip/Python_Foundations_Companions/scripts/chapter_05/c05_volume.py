bottles = 36
bottle_volume_liters = 0.5
volume_liters = bottles * bottle_volume_liters
 
print("Bottles filled:", bottles)
print("Estimated liters supplied:", volume_liters)
