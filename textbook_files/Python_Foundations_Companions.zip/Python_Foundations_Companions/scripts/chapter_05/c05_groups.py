cards = 53
cards_per_pack = 6
 
complete_packs = cards // cards_per_pack
leftover_cards = cards % cards_per_pack
 
print("Complete packs:", complete_packs)
print("Cards left over:", leftover_cards)
