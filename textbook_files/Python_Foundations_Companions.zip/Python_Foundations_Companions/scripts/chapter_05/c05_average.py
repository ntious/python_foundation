morning_liters = 12.0
midday_liters = 18.0
evening_liters = 15.0
 
total_liters = morning_liters + midday_liters + evening_liters
average_liters = total_liters / 3
 
print("Total liters:", total_liters)
print("Average liters per session:", average_liters)
