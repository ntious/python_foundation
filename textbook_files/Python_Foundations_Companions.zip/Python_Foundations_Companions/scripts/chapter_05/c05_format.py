volume_liters = 7.5
print(f"Recorded volume: {volume_liters:.2f} L")
