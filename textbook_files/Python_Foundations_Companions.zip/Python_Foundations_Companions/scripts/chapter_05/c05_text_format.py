event = "Stories by the quay"
reader = "Mara Cole"
venue = "East library"
print(f"{event} | Reader: {reader}")
print(f"Venue: {venue}")
