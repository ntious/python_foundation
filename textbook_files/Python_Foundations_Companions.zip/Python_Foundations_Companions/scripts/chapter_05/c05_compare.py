total_liters = 45.0
threshold_liters = 40.0
 
print("Above threshold:", total_liters > threshold_liters)
print("Exactly at threshold:", total_liters == threshold_liters)
print("At or below threshold:", total_liters <= threshold_liters)
