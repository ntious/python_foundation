print("Harbor Repair Cafe")
print("Bring one item to the welcome table.")
print("Keep your claim slip until collection.")
