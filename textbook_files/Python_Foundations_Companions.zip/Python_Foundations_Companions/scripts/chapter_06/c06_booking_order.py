bookings = 20
if bookings >= 20:
    print("Full")
elif bookings >= 16:
    print("Nearly full")
else:
    print("Places available")
