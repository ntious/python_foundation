total_liters = 12.0
visitors = 0
 
if visitors > 0:
    liters_per_visitor = total_liters / visitors
    print("Liters per visitor:", liters_per_visitor)
else:
    print("A positive visitor count is required.")
