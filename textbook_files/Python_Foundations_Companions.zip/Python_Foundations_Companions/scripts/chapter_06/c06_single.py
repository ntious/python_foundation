hour = 17
 
if hour >= 17:
    print("The room has closed for today.")
 
print("Thank you for checking the notice.")
