hour = 16
 
if hour < 9:
    print("The room opens at 09:00.")
elif hour < 17:
    print("The reading room is open.")
else:
    print("The room has closed for today.")
