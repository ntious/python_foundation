parcel_ready = False
 
if parcel_ready:
    print("Your collection parcel is ready.")
else:
    print("Please check again later.")
