def show_collection_note():
    print("Place the label beside the covered dish.")
    print("Keep the collection area clear.")
 
show_collection_note()
show_collection_note()
