def show_plot_task(plot_name):
    print("Water the seedlings in", plot_name)
 
plot_names = ["North plot", "Orchard plot"]
 
for name in plot_names:
    show_plot_task(name)
