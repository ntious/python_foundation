def show_dish_label(dish_name):
    print("Prepared dish:", dish_name)
    print("Collect at the community table.")
 
show_dish_label("Vegetable stew")
show_dish_label("Lentil salad")
