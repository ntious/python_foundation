def water_needed_liters(portions):
    liters_per_portion = 0.25
    return portions * liters_per_portion
 
water_liters = water_needed_liters(6)
print(f"Water for preparation: {water_liters:.2f} L")
