def show_rate():
    liters_per_portion = 0.25
    print(liters_per_portion)

show_rate()
