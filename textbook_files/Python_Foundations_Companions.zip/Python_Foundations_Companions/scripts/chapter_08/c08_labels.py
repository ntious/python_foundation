for plot_index in range(3):
    print("Planting plot", plot_index + 1)
 
print("Labels complete.")
