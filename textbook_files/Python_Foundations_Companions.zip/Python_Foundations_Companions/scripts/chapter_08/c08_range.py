for marker_number in range(1, 4):
    print("Route marker", marker_number)
