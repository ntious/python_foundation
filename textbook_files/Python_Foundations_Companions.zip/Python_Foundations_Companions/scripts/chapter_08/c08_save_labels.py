with open("archive_labels_01.txt", "x",
          encoding="utf-8") as report:
    for label_number in range(1, 4):
        report.write(f"Archive folder {label_number}\n")
print("Saved archive_labels_01.txt")
