total = 4
total = total + 3
print(total)
total = 4
total += 3
print(total)
