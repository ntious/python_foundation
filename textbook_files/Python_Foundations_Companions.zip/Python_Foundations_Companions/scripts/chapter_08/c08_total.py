daily_bags = 4
total_bags = 0
 
for day_index in range(3):
    total_bags = total_bags + daily_bags
    print(f"After day {day_index + 1}: {total_bags}")
 
print("Total bags allocated:", total_bags)
