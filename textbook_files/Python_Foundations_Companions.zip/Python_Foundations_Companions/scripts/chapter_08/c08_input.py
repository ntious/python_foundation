total_refills = 0
 
for round_index in range(3):
    print("Survey round", round_index + 1)
    count_text = input("Nonnegative refill count this round: ")
    feeder_count = int(count_text)
    total_refills = total_refills + feeder_count
 
print("Total refill actions:", total_refills)
