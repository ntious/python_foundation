topic = input("Topic (or done): ").strip()
while topic.lower() != "done":
    print("Queued:", topic)
    topic = input("Topic (or done): ").strip()
print("Topic list finished.")
