while True:
    choice = input("Type help or done: ").strip().lower()
    if choice == "done":
        break
    elif choice == "help":
        print("Enter a topic, then record its minutes.")
    else:
        print("Choose help or done.")
print("Session ended.")
