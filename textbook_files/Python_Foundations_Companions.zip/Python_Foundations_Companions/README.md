# Python Foundations Draft 8 companions

This package was reconstructed from the revised manuscript because the original Draft 5 ZIP was not available. It contains the printed programs, supplied data, thirteen notebook companions, and selected solutions. It does not claim to preserve unprovided Draft 5 supplementary files.

Use Python 3.12 or later. The revision was executed on the Python interpreter recorded in the accompanying verification report; no operating-system interface trial is claimed.

1. Extract the ZIP before opening files.
2. For local work, open a script in IDLE and choose Run > Run Module. Data are copied beside the Chapter 12 and Chapter 13 programs, project, and solutions for convenience. Keep your attempts separate from the originals.
3. Read-only programs expect their input files in Python's current working folder. Check with import os; print(os.getcwd()).
4. Save examples use mode "x": running them twice with the same output name raises FileExistsError unless the example catches it. Pick a new filename or rename the earlier practice output.
5. For browser notebooks, upload a chapter notebook, run its setup cell, then work down the examples. Download the notebook and generated data files separately. Temporary practice files do not persist after the session ends.
6. c13_join.py contains the previously taught functions plus the joining function printed in Section 13.9. projects/study_tracker.py is the self-contained complete reference in Section 13.12.
7. Use invented data for practice. Examples are educational and do not measure study quality or verify real-world records.

Python code examples are offered under the book's MIT code license. The book's prose and illustrations retain their stated rights. See LICENSE_CODE.txt.

## Review and verification

See Python_Foundations_Draft_7_Execution_Record.md for the tested environment and reproducible command. Run tools/verify_release.py with Python 3.12 or later. The expected results and detailed execution record are in verification/.

PROVENANCE_INVENTORY.csv and Python_Foundations_Draft_7_Author_Checklist.md require author confirmation before publication. BEGINNER_TRIAL.md is an unfilled trial protocol, not a claim of observed learner results. The six scripts in deliberate_errors/ intentionally fail and are shown as text cells in notebooks.

## Review and verification

See Python_Foundations_Draft_7_Execution_Record.md for the tested environment and reproducible command. Run tools/verify_release.py with Python 3.12 or later. The expected results and detailed execution record are in verification/.

PROVENANCE_INVENTORY.csv and Python_Foundations_Draft_7_Author_Checklist.md require author confirmation before publication. BEGINNER_TRIAL.md is an unfilled trial protocol, not a claim of observed learner results. The six scripts in deliberate_errors/ intentionally fail and are shown as text cells in notebooks.

## Draft 8 edition update

Draft 8 adds author-approved acknowledgments and an About the Author section. Programming examples are unchanged from Draft 7. Earlier Draft 7 response and execution documents are retained as historical technical records. See Python_Foundations_Draft_8_Revision_Notes.md for this edition.
