# Python Foundations: textbook companion files

This package accompanies Python Foundations by Isaac K. Nti. It contains printed
programs, sample data, thirteen chapter notebooks, selected solutions, and the
intentional-error examples used in the book. These chapter companions are separate
from the OER's numbered 00–12 course notebooks.

Use Python 3.12 or later for these textbook companions.

1. Extract the ZIP before opening files. Keep your attempts separate from the originals.
2. For local work, open a script in IDLE and choose Run > Run Module. Data are copied
   beside Chapter 12/13 programs, projects, and solutions for convenience.
3. Read-only programs expect their input files in Python's current working folder.
   Check with `import os; print(os.getcwd())` if a file cannot be found.
4. Save examples using mode "x" can raise FileExistsError on a second run with the
   same output name. Choose a new filename or rename the earlier practice output.
5. For browser notebooks, upload a chapter notebook, run its setup cell, then work
   through the examples. Download notebooks and generated data files separately
   before leaving a temporary session.
6. `scripts/chapter_13/c13_join.py` assembles the previously taught functions;
   `projects/study_tracker.py` is the complete reference project. The
   `example_manifest.json` file maps printed program names to their source files.
7. The six scripts in `deliberate_errors/` intentionally fail; their notebook
   counterparts are shown as text cells. Read the book's debugging instructions.
8. Use invented practice data. Examples do not measure study quality or verify
   real-world records.

Python code examples retain the MIT code license in LICENSE_CODE.txt. The book's
prose and illustrations retain their stated rights.

Course website: https://ntious.github.io/python_foundation/
