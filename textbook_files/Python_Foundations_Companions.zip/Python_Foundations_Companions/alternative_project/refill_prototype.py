station_label = "Quay refill point"
session_cl = [5, 224, 971]
 
total_cl = sum(session_cl)
total_liters = total_cl / 100
mean_liters = total_liters / len(session_cl)
 
if total_cl > 1200:
    message = "Review the next supply plan."
else:
    message = "Within the planning threshold."
 
print("Station:", station_label)
print(f"Total supplied: {total_liters:.2f} L")
print(f"Mean per session: {mean_liters:.2f} L")
print(message)
