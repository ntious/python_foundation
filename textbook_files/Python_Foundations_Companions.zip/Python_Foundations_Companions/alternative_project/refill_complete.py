station_label = input("Station label: ")
session_cl = []
all_valid = True
 
for session_index in range(3):
    print("Session", session_index + 1)
    volume_text = input("Whole cL, 0 to 10000: ")
 
    try:
        volume_cl = int(volume_text)
    except ValueError:
        print("Enter a whole number of cL.")
        all_valid = False
    else:
        if volume_cl >= 0 and volume_cl <= 10000:
            session_cl.append(volume_cl)
        else:
            print("The count must be 0 to 10000 cL.")
            all_valid = False
 
if all_valid:
    total_cl = sum(session_cl)
    total_liters = total_cl / 100
    mean_liters = total_liters / len(session_cl)
 
    if total_cl > 1200:
        message = "Review the next supply plan."
    else:
        message = "Within the planning threshold."
 
    print("Station:", station_label)
    print("Session centiliters:", session_cl)
    print(f"Total supplied: {total_liters:.2f} L")
    print(f"Mean per session: {mean_liters:.2f} L")
    print(message)
else:
    print("Summary withheld: a session was rejected.")
    print("Rerun and enter all three counts again.")
