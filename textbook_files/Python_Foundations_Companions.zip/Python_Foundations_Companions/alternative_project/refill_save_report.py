station_label = "Quay refill point"
session_cl = [5, 224, 971]
total_cl = sum(session_cl)
total_liters = total_cl / 100
mean_liters = total_liters / len(session_cl)
 
if total_cl > 1200:
    message = "Review the next supply plan."
else:
    message = "Within the planning threshold."

with open("refill_summary_01.txt", "x",
          encoding="utf-8") as report:
    report.write(f"Station: {station_label}\n")
    report.write(f"Session cL: {session_cl}\n")
    report.write(
        f"Total supplied: {total_liters:.2f} L\n")
    report.write(
        f"Mean per session: {mean_liters:.2f} L\n")
    report.write(message + "\n")
print("Saved refill_summary_01.txt")
